import{j as a}from"./index-BAvcR41Q.js";const i=({children:s,className:t=""})=>a.jsx("div",{className:`page-transition ${t}`,children:s});export{i as P};
